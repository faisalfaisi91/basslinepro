<?php
if (!class_exists('ARM_Admin_mycred_feature'))
{
    class ARM_Admin_mycred_feature 
    {
        var $ismyCREDFeature;
        function __construct()
        {
            global $wpdb, $ARMember;
            $arm_admin_mycred_feature = get_option('arm_is_mycred_feature');
            $this->ismyCREDFeature = ($arm_admin_mycred_feature == '1') ? true : false;
            add_action('mycred_deactivation',array(&$this, 'arm_mycred_deactivation'));
        }
        function arm_mycred_deactivation()
        {
            update_option('arm_is_mycred_feature', 0);
        }
    }
}
global $arm_admin_mycred_feature;
$arm_admin_mycred_feature = new ARM_Admin_mycred_feature();
$arm_is_mycred_active = get_option('arm_is_mycred_feature');
if(!empty($arm_is_mycred_active) && $arm_is_mycred_active==1)
{
    add_filter('mycred_setup_hooks','arm_mycred_hook');
    function arm_mycred_hook($arm_mycred_installed)
    {
        $arm_mycred_installed['arm_mycred'] = array(
            'title' => __('ARMember Membership', 'ARMember'),
            'description' => __('ARMember Premium Plugin - Buy Membership Plan Hook', 'ARMember'),
            'callback' => array('ARM_mycred_feature')
            );
        return $arm_mycred_installed;
    }
    add_action('mycred_load_hooks','arm_mycred_custom_hook');
    function arm_mycred_custom_hook()
    {
        if(file_exists(MEMBERSHIP_CLASSES_DIR . "/class.arm_mycred_feature.php")){
            require_once( MEMBERSHIP_CLASSES_DIR . "/class.arm_mycred_feature.php");
        }
    }
}