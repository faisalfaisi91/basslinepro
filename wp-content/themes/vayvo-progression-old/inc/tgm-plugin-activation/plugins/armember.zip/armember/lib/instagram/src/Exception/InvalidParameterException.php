<?php namespace Andreyco\Instagram\Exception;

use Exception;

class InvalidParameterException extends Exception {}
