<?php

namespace Stripe\Error;

class Stripe_Authentication extends Base
{
}
