<?php

if (!class_exists('ARM_Report_Analytics')) {
	class ARM_Report_Analytics {
		public function __construct(){
			
			add_action('wp_ajax_armupdatecharts', array($this, "armupdatecharts"));

			add_action('wp_ajax_armupdatereportgrid', array( $this, 'arf_update_report_grid_data'));

			add_action('admin_footer', array( $this, 'arm_set_reports_submenu') );
		}

		public function armupdatecharts()
		{
			$type = $_POST['type'];
		    $graph_type = $_POST['graph_type'];
		    $is_pagination = false;
		    require_once(MEMBERSHIP_VIEWS_DIR . '/arm_graph_ajax.php');

		    die();
		}

		public function arf_update_report_grid_data(){
			
			$type = $_POST['type'];
		    $graph_type = $_POST['graph_type'];
		    $is_pagination = true;
		    require_once(MEMBERSHIP_VIEWS_DIR . '/arm_graph_ajax.php');

		    die();
		}

		public function arm_set_reports_submenu(){
			global $arm_slugs;
			$member_url = admin_url('admin.php?page='.$arm_slugs->report_analytics.'&action=member_report');
			$payment_url = admin_url('admin.php?page='.$arm_slugs->report_analytics.'&action=payment_report');

			$member_page = $payment_page = '';

			if( isset( $_GET['action'] ) && $_GET['action'] == 'member_report' ){
				$member_page = ' arm-current-menu ';
			} else if( isset( $_GET['action'] ) && $_GET['action'] == 'payment_report' ){
				$payment_page = ' arm-current-menu ';
			}

			$current_color = get_user_option( 'admin_color' );			

			$script = "<script>";
				$script .= "jQuery(document).ready(function(){";
					$script .= "var parent = jQuery('.arm-submenu-item.arm_report_analytics');";					
					$script .= "var child1 = jQuery('<li class=\"arm-submenu-item ".$member_page." arm_member_report_analytics\"><a href=\"".$member_url."\">".esc_html__('Members Reports', 'ARMember')."</a></li>');";
					$script .= "var child2 = jQuery('<li class=\"arm-submenu-item ".$payment_page." arm_member_report_analytics\"><a href=\"".$payment_url."\">".esc_html__('Payments Reports', 'ARMember')."</a></li>');";
					$script .= "var child_wrapper = jQuery('<ul class=\"wp-submenu wp-submenu-wrap arm-submenu-wrapper\"></ul>');";
					$script .= "parent.append( child_wrapper );";
					$script .= "child_wrapper.append( child1 );";
					$script .= "child_wrapper.append( child2 );";
				$script .= "});";				
			$script .= "</script>";

			$hover_color = "#00b9eb";
			$normal_color = "rgba(240,245,250,.7)";
			$active_color = "#ffffff";		

			if( !isset( $current_color ) || $current_color == '' ){
				$current_color = 'fresh';
			}

			if( 'fresh' == $current_color ){
				$hover_color = "#00b9eb";
				$normal_color = "rgba(240,245,250,.7)";
				$active_color = "#ffffff";		
			} else if( 'light' == $current_color ){
				$normal_color = '#686868';
				$hover_color = "#04a4cc";
				$active_color = "#333";
			} else if( 'blue' == $current_color ){
				$normal_color = '#e2ecf1';
				$hover_color = "#fff";
				$active_color = "#fff";
			} else if( 'coffee' == $current_color ){
				$normal_color = '#cdcbc9';
				$hover_color = "#c7a589";
				$active_color = "#fff";
			} else if( 'ectoplasm' == $current_color ){
				$normal_color = '#cbc5d3';
				$hover_color = "#a3b745";
				$active_color = "#fff";
			} else if( 'midnight' == $current_color ){
				$normal_color = '#c3c4c5';
				$hover_color = "#e14d43";
				$active_color = "#fff";
			} else if( 'ocean' == $current_color ){
				$normal_color = '#d5dde0';
				$hover_color = "#9ebaa0";
				$active_color = "#fff";
			} else if( 'sunrise' == $current_color ){
				$normal_color = '#f1c8c7';
				$hover_color = "#f7e3d3";
				$active_color = "#fff";
			}

			$script .= "<style type='text/css'>";
				$script .= ".arm-submenu-item.arm_report_analytics{position:relative !important;}";
				$script .= "li.toplevel_page_arm_manage_members.opensub .arm-submenu-item.arm_report_analytics ul.arm-submenu-wrapper{display:none !important;}";
				$script .= "li.toplevel_page_arm_manage_members.opensub .arm-submenu-item.arm_report_analytics:hover ul.arm-submenu-wrapper{display:block !important;margin-top:0 !important;}";
				$script .= ".arm-submenu-wrapper li a{padding-left: 25px !important; font-weight:normal !important;color:{$normal_color} !important;}";
				$script .= ".arm-submenu-wrapper li a:hover{ color:{$hover_color} !important; }";
				$script .= ".arm-submenu-wrapper li.arm-current-menu a{ color: {$active_color} !important; font-weight:600 !important; }";
				$script .= ".arm-submenu-wrapper li.arm-current-menu a:hover{ color: {$hover_color} !important; font-weight:600 !important; }";
			$script .= "</style>";

			echo $script;
		}
	}
	new ARM_Report_Analytics();
}

?>