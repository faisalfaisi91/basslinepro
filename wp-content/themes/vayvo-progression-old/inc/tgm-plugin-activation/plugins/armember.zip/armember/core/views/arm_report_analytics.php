<?php
global $wp, $wpdb, $ARMember, $arm_slugs, $arm_global_settings, $arm_members_class, $arm_subscription_plans, $arm_payment_gateways;

if (!current_user_can('administrator')) {
    wp_die("<h2>You don't have enough permission to access this page.</h2>");
}

$all_members = $arm_members_class->arm_get_all_members_without_administrator(0,1);
$recent_members = $arm_members_class->arm_get_all_members_without_administrator(1,1,1);
$total_members = (!empty($all_members)) ? $all_members : 0;

$before_week = strtotime('-6 days', strtotime(current_time('mysql')));
$before_week = date('Y-m-d 00:00:00', $before_week);
$current_date = date('Y-m-d 23:59:00', strtotime(current_time('mysql')));

$recent_query_payment = "SELECT SUM(arm_amount) recent_amount FROM ".$ARMember->tbl_arm_payment_log." WHERE arm_transaction_status='success' AND arm_payment_date >= '".$before_week."' AND arm_payment_date <= '".$current_date."'";

$recent_query_bank = "SELECT SUM(arm_amount) recent_amount FROM ".$ARMember->tbl_arm_bank_transfer_log." WHERE arm_status=1 AND arm_created_date >= '".$before_week."' AND arm_created_date <= '".$current_date."'";

$recent_query_payment = "SELECT IFNULL((".$recent_query_payment."),0) + IFNULL((".$recent_query_bank."),0) AS recent_amount";

$total_query = "SELECT IFNULL((SELECT SUM(arm_amount) FROM ".$ARMember->tbl_arm_payment_log." WHERE arm_transaction_status='success'),0) + IFNULL((SELECT SUM(arm_amount) FROM ".$ARMember->tbl_arm_bank_transfer_log." WHERE arm_status=1),0) AS total_amount";


$recent_payment = $wpdb->get_row($recent_query_payment);

$recent_payment = !empty($recent_payment) ? sprintf("%.2f", $recent_payment->recent_amount) : sprintf("%.2f",0);

$total_payment = $wpdb->get_row($total_query);
$total_payment = !empty($total_payment) ? sprintf("%.2f", $total_payment->total_amount) : sprintf("%.2f",0);

$currency = ""; $place = "";
$all_global_settings = $arm_global_settings->arm_get_all_global_settings();
if(!empty($all_global_settings)) {
    $general_settings = $all_global_settings['general_settings'];

    $global_currency = $arm_payment_gateways->arm_get_global_currency();
    $all_currency = $arm_payment_gateways->arm_get_all_currencies();
    $currency = $all_currency[strtoupper($global_currency)];

    //$currency = $general_settings['paymentcurrency'];
    $place = isset($general_settings['custom_currency']['place']) ? $general_settings['custom_currency']['place'] : 'prefix';
    $total_payment = ('sufix' == $place) ? $total_payment." ".$currency : $currency." ".$total_payment;
    $recent_payment = ('sufix' == $place) ? $recent_payment." ".$currency : $currency." ".$recent_payment;
}

global $arm_members_activity;
$setact = 0;
global $check_sorting;
$setact = $arm_members_activity->$check_sorting();

?>

<div class="wrap arm_page arm_report_analytics_main_wrapper">
	<div class="content_wrapper arm_report_analytics_content" id="content_wrapper">
		<div class="page_title">
			<?php _e('Reports','ARMember');?>
            <?php
				if ($setact != 1) {
					$admin_css_url = admin_url('admin.php?page=arm_manage_license');
					?>
			
					<div style="margin-top:20px;margin-bottom:10px;border-left: 4px solid #ffba00;box-shadow: 0 1px 1px 0 rgba(0, 0, 0, 0.1);height:20px;width:99%;padding:10px 25px 10px 0px;background-color:#f2f2f2;color:#000000;font-size:17px;display:block;visibility:visible;text-align:right;" >ARMember License is not activated. Please activate license from <a href="<?php echo $admin_css_url; ?>">here</a></div>
			<?php } ?>
			<div class="armclear"></div>
		</div>

		<div class="armclear"></div>

		<div class="arm_dashboard_member_summary">
            <div class="arm_total_members arm_member_summary">
                <a href="<?php echo admin_url('admin.php?page='.$arm_slugs->report_analytics.'&action=member_report');?>" class="welcome-icon">
                    <div class="arm_member_summary_count"><?php echo $total_members;?></div>
                    <div class="arm_member_summary_label"><?php _e('Total Members', 'ARMember');?></div>
                </a>
            </div>
            <div class="arm_active_members arm_member_summary">
                <a href="<?php echo admin_url('admin.php?page='.$arm_slugs->report_analytics.'&action=member_report');?>" class="welcome-icon">
                    <div class="arm_member_summary_count"><?php echo $recent_members;?></div>
                    <div class="arm_member_summary_label"><?php echo sprintf(esc_html__('Recent Members %slast week%s', 'ARMember'),'(',')');?></div>
                </a>
            </div>
            <div class="arm_inactive_members arm_member_summary">
                <a href="<?php echo admin_url('admin.php?page='.$arm_slugs->report_analytics.'&action=payment_report');?>" class="welcome-icon">
                    <div class="arm_member_summary_count"><?php echo $total_payment;?></div>
                    <div class="arm_member_summary_label"><?php _e('Total Payments', 'ARMember');?></div>
                </a>
            </div>
            <div class="arm_membership_plans arm_member_summary">
                <a href="<?php echo admin_url('admin.php?page='.$arm_slugs->report_analytics.'&action=payment_report');?>" class="welcome-icon">
                    <div class="arm_member_summary_count"><?php echo $recent_payment;?></div>
                    <div class="arm_member_summary_label"><?php echo sprintf(esc_html__('Recent Payments %slast week%s', 'ARMember'),'(',')');?></div>
                </a>
            </div>
        </div>

	</div>
</div>